import React from "react";

const Slide = (props)=>{
    return(
        <div  className = {props.cls +" col-md-12"}>
        </div>
    );
}

export default Slide;