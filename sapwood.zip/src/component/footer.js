import React from "react";

const Footer =()=>{
    return(
        <div className="footer row mb-5">
            <div className="col-md-12 mt-5 mb-5">
                <h3 className="text-primary">Delivering with the Love and care for to you relish</h3>
            </div>
            <div className="col-md-12 pt-3 pb-3 about-wrapper">
                <h5>About Demo Group</h5>
                <p>
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.
                </p>
            </div>
        </div>
    );
}
export default Footer;